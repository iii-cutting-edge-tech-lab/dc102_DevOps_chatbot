#!/bin/bash
docker run -p 5000:5000 --name flask-devops -d 204065533127.dkr.ecr.ap-northeast-1.amazonaws.com/devops-test
